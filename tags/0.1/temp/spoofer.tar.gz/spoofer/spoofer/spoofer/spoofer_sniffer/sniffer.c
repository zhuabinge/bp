#include <pcap/pcap.h>
#include <pcap.h>

#include "spoofer_sniffer.h"
#include "../spoofer_main/spoofer_main.h"
#include "../spoofer_ipcs/spoofer_ipcs.h"
#include "../spoofer_kernel/spoofer_kernel.h"
#include "../spoofer_mem_pool/mem_pool.h"
#include "../spoofer_file/spoofer_file.h"

#define SPOOFER_CATCHED_PACKET_LEN (65535)
#define SPOOFER_MSQID_DS_SIZE (int)sizeof(struct msqid_ds)

/* the filed amount of line is 3 for http 1/1, mothed, url and http vision */
#define SPOOFER_HTTP_LINE_FIELD_AMOUNT (3)

#define SPOOFER_HTTP_DOMAIN_LEN (128)

#define LF     (u_char) '\n'    /* 0x0a */
#define CR     (u_char) '\r'    /* 0x0d */
#define CRLF   "\r\n"

spo_str_t *http_line = NULL;    /* the http line pointer */

int counter = 0;            /* the counter for rr */

struct msqid_ds spo_msg_info;   /* use to save the msg queue info */

/* for test 10.25 */
typedef struct spo_domain_s {
    int fd;
    ulong dmn_counter;
    size_t len;
    char domain[128];
}spo_domain_t;

spo_domain_t *match_domains = NULL;  /* just for test */

ulong www_baidu_com = 0;
ulong wp_mail_qq_com = 0;
ulong toruk_tanx_com = 0;
ulong ecpm_tanx_com = 0;
ulong apollon_t_taobao_com = 0;
ulong tmatch_simba_taobao_com = 0;
ulong pos_baidu_com = 0;
ulong item_yhd_com = 0;
ulong suggestion_baidu_com = 0;
ulong cb_baidu_com = 0;
ulong open_show_qq_com = 0;


/**
 *
 *  the packet is in 802.3 -1q vlan ?
 *
 *  @param packet, the packet we catch.
 *
 *  @return the judgment result.
 *
 *  status finished, tested.
 *
 *  ok
 *
 **/

inline SPO_RET_BOOLEN_INT spo_is_802_1q_vlan(const u_char *packet) {

    spo_sniff_ether_t *eth = (spo_sniff_ether_t *) packet;

    if (ntohs(eth->ether_type) == 0x8100) {
        printf("is --- vlan *******\nSPOOFER_B");
        return SPOOFER_TRUE;
    }

    return SPOOFER_FALSE;
}



/**
 *
 *  when we catch the http packet, we get the http packets's size in here.
 *
 *  @param packet, is the http packet we catched.
 *
 *  @return size, is the packet total size.
 *
 **/

inline size_t spo_http_packet_size(const u_char *packet) {

    size_t packet_size = 0;

    if (packet == NULL) {
        return SPOOFER_FAILURE;
    }

    if (spo_is_802_1q_vlan(packet) == SPOOFER_TRUE) {   /* is running vlan env */

        spo_sniff_ip_t *ip =  (spo_sniff_ip_t *) (packet + SPOOFER_IP_OFFSET_VLAN);

        /* packet size eq ip len + vlan header len + eth header len */
        packet_size = ntohs(ip->ip_len) + SPOOFER_IP_OFFSET_VLAN;

        return packet_size;

    }else {

        spo_sniff_ip_t *ip =  (spo_sniff_ip_t *) (packet + LIBNET_ETH_H);

        packet_size = ntohs(ip->ip_len) + LIBNET_ETH_H;

        return packet_size;

    }
}


/**
 *
 *  get the http packet's tcp level options's length.
 *
 *  the option length < 40 byte.
 *
 *  @param packet, is the http request packet we catched.
 *
 *  @return op_len, is the options's length.
 *
 *  ok
 *
 **/

short spo_get_tcp_options_len(const u_char *packet) {

    short op_len = -1;
    spo_sniff_tcp_t *tcp = NULL;

    if (packet == NULL) {
        return SPOOFER_FAILURE;
    }

    if (spo_is_802_1q_vlan(packet) == SPOOFER_TRUE) {
        tcp = (spo_sniff_tcp_t *) (packet + SPOOFER_TCP_OFFSET_VLAN);
    }else {
        tcp = (spo_sniff_tcp_t *) (packet + SPOOFER_TCP_OFFSET);
    }

    op_len = (short) ((short)(tcp->tcp_offx2 >> 2) - LIBNET_TCP_H);

    return op_len;
}

/**
 *
 *  get the http request packet start pointer.
 *
 *  @param packet, is the http request packet we catched.
 *
 *  @return http_start, is the http start pointer.
 *
 *  ok
 *
 **/

const u_char *spo_http_start(const u_char *packet) {

    u_char *http_start = NULL;

    if (packet == NULL) {
        return NULL;
    }

    if (spo_is_802_1q_vlan(packet) == SPOOFER_TRUE) {
        http_start = (u_char *) (packet + SPOOFER_TCP_OFFSET_VLAN
                                 + LIBNET_TCP_H + spo_get_tcp_options_len(packet));
    }else {
        http_start = (u_char *) (packet + SPOOFER_TCP_OFFSET
                                 + LIBNET_TCP_H + spo_get_tcp_options_len(packet));
    }

    if ((long)spo_http_packet_size(packet) == (http_start - packet)) {
        return NULL;
    }

    return http_start;
}


/**
 *
 *  get the http request packet method.
 *
 *  @param packet, is the packet we catched.
 *
 *  @param method, used to save the method name and name's len.
 *
 *  @return int, is the exec status.
 *
 **/

SPO_RET_STATUS_INT spo_http_request_method(const u_char *http_start, spo_str_t *mtd, int mtd_off) {


    u_char *ch = NULL;

    if (mtd == NULL) {
        mtd->data = NULL;
        mtd->len = 0;
        return SPOOFER_FAILURE;
    }

    if (http_start == NULL) {
        mtd->data = NULL;
        mtd->len = 0;
        return SPOOFER_OK;
    }

    ch = (u_char *) (((u_char *)http_start) + mtd_off);

    if (*ch == CR || *ch == LF) {
        mtd->data = NULL;
        mtd->len = 0;
        return SPOOFER_OK;
    }

    while (*ch == 0x20) {    //skip the ' ', hex is 0x20
        ch++;
    }

    mtd->data = ch;

    while (*ch != 0x20) {
        ch++;
    }

    mtd->len = (size_t)(ch - mtd->data);
    if (mtd->len == 0) {
        mtd->data = NULL;
        mtd->len = 0;
        return SPOOFER_FAILURE;
    }

    return SPOOFER_OK;
}


/**
 *
 *  get the http request url.
 *
 *  and save the url at param url
 *
 *
 **/

SPO_RET_STATUS_INT spo_http_request_url(const u_char *http_start, spo_str_t *url, int url_off, size_t pkt_s) {

    u_char *ch = NULL;
    size_t i = 0;

    if (url == NULL) {
        return SPOOFER_FAILURE;
    }

    if (http_start == NULL) {
        url->data = NULL;
        url->len = 0;
        return SPOOFER_OK;
    }

    ch = (u_char *) (((u_char *) http_start) + url_off);

    url->data = ch;

    for (i = 0; i < pkt_s; i++) {
        if (*ch == 0x20) {
            break;
        }
        ch++;
    }

    if (i >= pkt_s) {
        url->data = NULL;
        url->len = 0;
        return SPOOFER_FAILURE;
    }

    url->len = (size_t) (ch - url->data);
    if (url->len == 0) {
        url->data = NULL;
        url->len = 0;
        return SPOOFER_FAILURE;
    }

    return SPOOFER_OK;

}


SPO_RET_STATUS_INT spo_http_version(const u_char *http_start, spo_str_t *version, int url_off, size_t pkt_s) {

    u_char *ch = NULL;
    size_t i = 0;

    if (version == NULL) {
        return SPOOFER_FAILURE;
    }

    if (http_start == NULL) {
        version->data = NULL;
        version->len = 0;
        return SPOOFER_OK;
    }

    ch = (u_char *) (((u_char *) http_start) + url_off);

    version->data = ch;

    for (i = 0; i < pkt_s; i++) {
        if (*ch == CR && *(ch + 1) == LF) {
            //printf("finished line\n");
            break;
        }
        ch++;
    }

    version->len = (size_t) (ch - version->data);
    if (version->len == 0) {
        version->data = NULL;
        version->len = 0;
        return SPOOFER_FAILURE;
    }

    return SPOOFER_OK;

}


/**
 *
 *  get the http request domain.
 *
 *  and save the domaim at param domain
 *
 *
 **/

SPO_RET_STATUS_INT spo_http_request_host(const u_char *http_start, spo_str_t *host, int host_off, size_t pkt_s) {

    size_t i = 0;
    u_char *field = NULL;

    if (host == NULL) {
        return SPOOFER_FAILURE;
    }

    u_char *ch = (u_char *) (((u_char *)http_start) + host_off);

    field = ch;

    for (i = 0; i < pkt_s; i++) {
        if (*ch == CR && *(ch + 1) == LF) {
            if (memcmp(field, "Host", 4) == 0) {
                break;
            }
            ch = ch + 2;
            field = ch;
            continue;
        }
        ch++;
    }

    host->data = field + 6;     /* skip the string "Host: " */
    ch = host->data;            /* the host(domain) start */

    for (i = 0; i < SPOOFER_HTTP_DOMAIN_LEN; i++) {
        if (*ch == CR && *(ch + 1) == LF) {
            break;
        }
        ch++;
    }

    host->len = i;

    return SPOOFER_OK;

}


/**
 *
 *  for test
 *
 **/

SPO_RET_BOOLEN_INT spo_domain_match(spo_domain_t *domains, spo_str_t *host) {

    int i = 0;

    if (domains == NULL || host == NULL) {
        perror("domain and host is null in spo_domain_match\n");
        return SPOOFER_FAILURE;
    }

    for (i = 0; i < 11; i++) {

        if (domains[i].len == host->len) {

            if (memcmp(domains[i].domain, host->data, domains[i].len) == 0) {
                domains[i].dmn_counter++;
                printf("------\n");
                u_char *ch = host->data;
                int ii = 0;
                for (ii = 0; ii < host->len; ii++) {
                    printf("%c",*ch);
                    ch++;
                }
                printf("\n");

                if (domains[i].dmn_counter >= 10000) {
                    domains[i].dmn_counter = 0;
                    int ret = spo_write(domains[i].fd, "10000\n", strlen("10000\n"));
                    if (ret == -1) {
                        return SPOOFER_FALSE;
                    }
                }

                return SPOOFER_TRUE;
            }

        }

    }

    return SPOOFER_FALSE;
}


/**
 *
 *  analysis the packets we catched.
 *
 * */
SPO_RET_STATUS_INT spo_analysis_http_line(const u_char *packet, spo_str_t *line) {

    int offset = -1;
    int ret = -1;
    size_t pkt_s = 0;

    if (packet == NULL || line == NULL) {
        return SPOOFER_FAILURE;
    }

    pkt_s = spo_http_packet_size(packet);

    const u_char *http_start = spo_http_start(packet);

    /* get the request method */

    if (http_start == NULL) {
        goto bad_analysis;
    }else {
        ret = spo_http_request_method(http_start, &line[0], 0);

        if (ret == SPOOFER_FAILURE) goto bad_analysis;

        if (!(line[0].len == 3 && memcmp(line[0].data, "GET", 3) == 0)) {
            goto bad_analysis;
        }
    }

    /* get the request url */

    if (line[0].len == 0 || line[0].data == NULL) {
        goto bad_analysis;
    }else {
        offset = line[0].len + 1;   /* add 1 is skip the ' '(0x20) */

        ret = spo_http_request_url(http_start, &line[1], offset, pkt_s);

        if (ret == SPOOFER_FAILURE) goto bad_analysis;
    }

    /* get the http version */
    if (line[1].len == 0 || line[1].data == NULL) {
        goto bad_analysis;
    }else {
        offset = offset + line[1].len + 1;

        ret = spo_http_version(http_start, &line[2], offset, pkt_s);
        if (ret == SPOOFER_FAILURE) goto bad_analysis;
    }

    if (line[2].len == 0 || line[2].data == NULL) {
        goto bad_analysis;
    }else {
        offset = offset + line[2].len + 2; /* skip the '\r\n' */
        ret = spo_http_request_host(http_start,&line[3], offset, pkt_s);
        if (ret == SPOOFER_FAILURE) goto bad_analysis;
    }

    if (line[3].len == 0 || line[3].data == NULL) {
        goto bad_analysis;
    }

    return SPOOFER_OK;

bad_analysis:

    return SPOOFER_FAILURE;

}


/**
 *
 *  when we catched a packet packet, we analysis it.
 *
 *  if this packet is we need, we get it's info that we need and save the info at hjk_info.
 *
 *  after save the info, we send the hjk_info to msg queue.
 *
 *  @param packet, is the packet we catched.
 *
 *  @return exec status.
 *
 **/

SPO_RET_STATUS_INT spo_analysis_http_packet(const u_char *packet) {

    int ret = -1;
    spo_str_t *line = NULL;

    if (packet == NULL) {
        return SPOOFER_FAILURE;
    }

    line = spo_calloc(sizeof(spo_str_t) * (SPOOFER_HTTP_LINE_FIELD_AMOUNT + 1));

    if (line == NULL) {
        /* wirte err log */
        return SPOOFER_FAILURE;
    }

    ret = spo_analysis_http_line(packet, line);
    if (ret == SPOOFER_FAILURE) {
        spo_free(line);
        return SPOOFER_FAILURE;
    }


    if (spo_domain_match(match_domains, &line[3]) == SPOOFER_TRUE) {
        spo_free(line);
        return SPOOFER_OK;
    }

    spo_free(line);
    return SPOOFER_FAILURE;
}


/**
 *
 *  get the msg queue status.
 *
 *  if more than 3 packets in msg queue, we discard the current packet.
 *
 *  @param msgid, is the msg queue id.
 *
 *  @return the queue status.
 *
 **/

inline SPO_RET_STATUS_INT spo_msg_queue_stat(int msgid) {

    int ret = msgctl(msgid, IPC_STAT, &spo_msg_info);

    if (ret == SPOOFER_FAILURE) {
        printf("get msg info err\n");
        return SPOOFER_FAILURE;
    }

    if (spo_msg_info.msg_qnum > 4) {
        //printf("too much packet--************************************\n");
        //printf("too much packet never deal with\n");
        memset(&spo_msg_info, 0, SPOOFER_MSQID_DS_SIZE);
        return SPOOFER_FAILURE;
    }

    memset(&spo_msg_info, 0, SPOOFER_MSQID_DS_SIZE);

    return SPOOFER_OK;
}


/**
 *
 *  when we catch a packet we callback here.
 *
 *
 **/

void spo_http_sniffer_callback(u_char *user, const struct pcap_pkthdr *pcap_head, const u_char *packet) {

    int msgid = msgids[0];
    int ret = -1;
    size_t packet_size = 0;

    if (packet == NULL) {
        return;
    }

    user = user;
    pcap_head = pcap_head;


    ret = spo_analysis_http_packet(packet);
    if (ret == SPOOFER_FAILURE) {
        return;
    }

    /* if the msg queue is not ok, we return */
    if (spo_msg_queue_stat(msgid) == SPOOFER_FAILURE) {
        return;
    }


    printf("send ---\n");
    spo_http_packet_msg_t http_packet_msg;

    packet_size = spo_http_packet_size(packet);
    if (packet_size > SPOOFER_MAX_PACKET_SIZE) {
        printf("packet too big\n");
        return;
    }

    memset(&http_packet_msg, '\0', SPOOFER_HTTP_PACKET_MSG_SIZE);

    http_packet_msg.msg_type = SPOOFER_HTTP_PACKET_MSG_TYPE;

    memcpy(http_packet_msg.packet, packet, packet_size);

    ret = spo_msgsnd(msgid, &http_packet_msg, SPOOFER_MAX_PACKET_SIZE, 0);
    if (ret == SPOOFER_FAILURE) {
        perror("send msg err\n");
        return;
    }
    printf("send finished\n");
    return;
}


/**
 *
 *  set the sniffer filter.
 *
 *  @param p, is the pcap handler.
 *
 *  @param filter_exp, is the exp to filte the packet.
 *
 *  @return exec status.
 *
 *  status finished, tested.
 *
 **/

SPO_RET_STATUS_INT spo_set_filter(pcap_t *p, const char *filter_exp) {

    int ret = -1;
    struct bpf_program bpf;

    if (filter_exp == NULL) {
        perror("filter is null\n");
        return SPOOFER_FAILURE;
    }

    /*compile the filter exp*/
    ret = pcap_compile(p, &bpf, filter_exp, 0, 0);
    if (ret == SPOOFER_FAILURE) {
        exit(EXIT_FAILURE);
    }

    /*set the filter*/
    ret = pcap_setfilter(p, &bpf);
    if (ret == SPOOFER_FAILURE) {
        exit(EXIT_FAILURE);
    }

    return SPOOFER_OK;
}


/**
 *  just for test.
 *
 **/
SPO_RET_STATUS_INT spo_init_domain_data(spo_domain_t *domains) {

    if (domains == NULL) {
        perror("domains is null\n");
        return SPOOFER_FAILURE;
    }

    memcpy(domains[0].domain, "www.baidu.com", strlen("www.baidu.com"));
    domains->len = strlen("www.baidu.com");

    memcpy(domains[1].domain, "wp.mail.qq.com", strlen("wp.mail.qq.com"));
    domains[1].len = strlen("wp.mail.qq.com");

    memcpy(domains[2].domain, "toruk.tanx.com", strlen("toruk.tanx.com"));
    domains[2].len = strlen("toruk.tanx.com");

    memcpy(domains[3].domain, "ecpm.tanx.com", strlen("ecpm.tanx.com"));
    domains[3].len = strlen("ecpm.tanx.com");

    memcpy(domains[4].domain, "apollon.t.taobao.com", strlen("apollon.t.taobao.com"));
    domains[4].len = strlen("apollon.t.taobao.com");

    memcpy(domains[5].domain, "tmatch.simba.taobao.com", strlen("tmatch.simba.taobao.com"));
    domains[5].len = strlen("tmatch.simba.taobao.com");

    memcpy(domains[6].domain, "pos.baidu.com", strlen("pos.baidu.com"));
    domains[6].len = strlen("pos.baidu.com");

    memcpy(domains[7].domain, "item.yhd.com", strlen("item.yhd.com"));
    domains[7].len = strlen("item.yhd.com");

    memcpy(domains[8].domain, "suggestion.baidu.com", strlen("suggestion.baidu.com"));
    domains[8].len = strlen("suggestion.baidu.com");

    memcpy(domains[9].domain, "cb.baidu.com", strlen("cb.baidu.com"));
    domains[9].len = strlen("cb.baidu.com");

    memcpy(domains[10].domain, "open.show.qq.com", strlen("open.show.qq.com"));
    domains[10].len = strlen("open.show.qq.com");



    if(access("/home/test_spoofer_log", 0) == -1){//access函数是查看文件是不是存在
        if (mkdir("/home/test_spoofer_log", 0777)){//如果不存在就用mkdir函数来创建
            printf("creat file bag failed!!!");
        }
    }

    int i = 0;
    for (i = 0; i < 11; i++) {
        int path_len  = 0;
        char temp[256];
        memset(temp, 0, 256);
        domains[i].dmn_counter = 0;

        memcpy(temp, "/home/test_spoofer_log/", sizeof("/home/test_spoofer_log/"));
        path_len = (int)strlen("/home/test_spoofer_log/");
        memcpy((temp + path_len), domains[i].domain, domains[i].len);
        printf("%s\n", temp);

        domains[i].fd = spo_open(temp, O_CREAT | O_RDWR, 0666);
        if (domains[i].fd == -1) {
            perror("open counter fd err\n");
            exit(EXIT_FAILURE);
        }
    }

    return SPOOFER_OK;

}


/**
 *
 *  spo_sniffer
 *  sniffer start here.
 *
 *  we catch the http request packet by libpcap.
 *
 *  @param filter, is the filter we filte the workers_logpacket.
 *
 *  @return nothing.
 *
 **/

void spo_sniffer(const char *filter_exp) {

    char *dev_r = (char *) "wlan0";

    if (filter_exp == NULL) {
        printf("filter is null\n");
    }

    int ret = -1;
    char errbuf[PCAP_ERRBUF_SIZE];
    pcap_t *handler;

    bpf_u_int32 mask;
    bpf_u_int32 net;

    /* find ip and ip mask in this dev */
    if (pcap_lookupnet(dev_r, &net, &mask, errbuf) == SPOOFER_FAILURE) {
        /* wirte log */
        net = 0;
        mask = 0;
        //exit(EXIT_FAILURE);
    }

    handler = pcap_open_live(dev_r, SPOOFER_CATCHED_PACKET_LEN, 1, 0, errbuf);
    if (handler == NULL) {
        /* wirte log */
        printf("pcap_open_live err \n");
    }

    ret = spo_set_filter(handler, filter_exp);
    if (ret == SPOOFER_FAILURE) {
        /* wirte log */
        exit(EXIT_FAILURE);
    }

    match_domains = malloc(11 * sizeof(spo_domain_t));
    if (match_domains == NULL) {
        perror("malloc match domain err\n");
    }

    spo_init_domain_data(match_domains);

    ret = pcap_loop(handler, -1, spo_http_sniffer_callback, NULL);

    if (ret < 0) {
        /* wirte log */
        exit(EXIT_FAILURE);
    }
}
