#ifndef SPOOFER_KERNEL_H
#define SPOOFER_KERNEL_H

#include <sys/types.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>
#include <assert.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <errno.h>

#define spo_string(str)     { sizeof(str) - 1, (u_char *) str }

typedef struct spo_string_s {
    size_t len;
    u_char *data;
}spo_string_t, spo_str_t;


#endif // SPOOFER_KERNEL_H
