#include <sys/msg.h>
#include <sys/wait.h>

#include "spoofer.h"
#include "../spoofer_mem_pool/mem_pool.h"
#include "../spoofer_ipcs/spoofer_ipcs.h"
#include "../spoofer_log/spoofer_log.h"
#include "../spoofer_test/test.h"
#include "../spoofer_sniffer/spoofer_sniffer.h"


#define SPO_PROC_TYPE_SNIFFER 0     /* this process type is sniffer */
#define SPO_PROC_TYPE_SPOOFER 1     /* this process type is spoffer */
#define SPOOFER_PROC_MEM_POOL_SIZE SPOOFER_PAGE_SIZE


int msgids[10];


/**
 *
 *  create a msg queue.
 *
 *  @param msgid_p, is the msgid but no a key_t type.
 *
 *  @param msgflg_perm, is the perm of the queue we create.
 *
 *  @return msgid, is the queue id we create.
 *
 **/

SPO_RET_VALUE_INT spo_create_msg_queue(int msgid_p, int msgflg_perm) {

    int msgid = -1;

    msgid = spo_msgget((key_t) msgid_p, msgflg_perm | IPC_CREAT);

    if (msgid == -1) {
        /* wirte log */
        exit(EXIT_FAILURE);
    }

    return msgid;
}

/**
 *  remove a msg queue.
 *
 *  @param msgid, is the queue id we will remove.
 *
 *  @return int, the exec status.
 *
 **/

static SPO_RET_STATUS_INT spo_remove_msg_queue(int msgid) {

    if (msgctl(msgid, IPC_RMID, 0) == -1) {
        printf("msg queue %d remove err\n", msgid);
        return SPOOFER_FAILURE;
    }

    printf("msg queue %d remove successful\n", msgid);

    return SPOOFER_OK;
}



int main () {

    msgids[0] = 12345690;
    const char *filter_exp = (char *) "tcp";

    msgids[0] = spo_create_msg_queue(msgids[0], IPC_CREAT | 0666);

    if (msgids[0] == SPOOFER_FAILURE) {
        printf("create msg queue err\n");
        exit(EXIT_FAILURE);
    }

    spo_sniffer(filter_exp);

    return 0;
}
