#ifndef SPOOFER_FILE_H
#define SPOOFER_FILE_H

SPO_RET_VALUE_INT spo_open(const char *file, int file_flg, int perm);
ssize_t spo_write(int fd, const void *buf, size_t size);
#endif // SPOOFER_FILE_H
